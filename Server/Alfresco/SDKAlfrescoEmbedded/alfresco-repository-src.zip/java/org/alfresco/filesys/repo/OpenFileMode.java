package org.alfresco.filesys.repo;

public enum OpenFileMode 
{
    READ_ONLY,
    WRITE_ONLY,
    READ_WRITE,
    DELETE,
    ATTRIBUTES_ONLY
}
