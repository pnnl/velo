/**
 * Implementation of desk top actions for file system protocols.
 */
package org.alfresco.filesys.repo.desk;
