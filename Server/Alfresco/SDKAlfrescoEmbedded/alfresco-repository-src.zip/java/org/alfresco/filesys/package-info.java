/**
 * The Alfresco file system interface implementation
 */
package org.alfresco.filesys;
