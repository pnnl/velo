/**
 */
package org.alfresco.filesys.config;
