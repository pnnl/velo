Jencks is a POJO and Spring extension to the Geronimo JCA container to support Message Driven POJOs.

For more details please see http://jencks.codehaus.org/
