/*
 * Copyright 2006 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jencks.factory;

import java.io.File;

import org.apache.geronimo.transaction.log.GeronimoHOWLLog;
import org.apache.geronimo.transaction.manager.TransactionLog;
import org.apache.geronimo.transaction.manager.XidFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;

/**
 * @version $Revision$ $Date$
 * @org.apache.xbean.XBean element="howlLog" 
 */
public class HowlLogFactoryBean implements FactoryBean, DisposableBean {
    private static GeronimoHOWLLog howlLog;

    private String logFileDir;
    private XidFactory xidFactory;

    private String bufferClassName = "org.objectweb.howl.log.BlockLogBuffer";
    private int bufferSizeKBytes = 32;
    private boolean checksumEnabled = true;
    private int flushSleepTimeMilliseconds = 50;
    private String logFileExt = "log";
    private String logFileName = "transaction";
    private int maxBlocksPerFile = -1;
    private int maxLogFiles = 2;
    private int maxBuffers = 0;
    private int minBuffers = 4;
    private int threadsWaitingForceThreshold = -1;
    private File serverBaseDir;

    public HowlLogFactoryBean() {
        String serverDir = System.getProperty("jencks.server.dir", System.getProperty("basedir", System.getProperty("user.dir")));
        serverBaseDir = new File(serverDir);
    }

    public Object getObject() throws Exception {
        if (howlLog == null) {
            howlLog = new GeronimoHOWLLog(bufferClassName,
                    bufferSizeKBytes,
                    checksumEnabled,
                    flushSleepTimeMilliseconds,
                    new File(serverBaseDir, logFileDir).getAbsolutePath(),
                    logFileExt,
                    logFileName,
                    maxBlocksPerFile,
                    maxBuffers,
                    maxLogFiles,
                    minBuffers,
                    threadsWaitingForceThreshold,
                    xidFactory);

            howlLog.doStart();
        }
        return howlLog;
    }

    public void destroy() throws Exception {
        if (howlLog != null) {
            howlLog.doStop();
            howlLog = null;
        }
    }

    public Class getObjectType() {
        return TransactionLog.class;
    }

    public boolean isSingleton() {
        return true;
    }

    public String getBufferClassName() {
        return bufferClassName;
    }

    public void setBufferClassName(String bufferClassName) {
        this.bufferClassName = bufferClassName;
    }

    public int getBufferSizeKBytes() {
        return bufferSizeKBytes;
    }

    public void setBufferSizeKBytes(int bufferSizeKBytes) {
        this.bufferSizeKBytes = bufferSizeKBytes;
    }

    public boolean isChecksumEnabled() {
        return checksumEnabled;
    }

    public void setChecksumEnabled(boolean checksumEnabled) {
        this.checksumEnabled = checksumEnabled;
    }

    public int getFlushSleepTimeMilliseconds() {
        return flushSleepTimeMilliseconds;
    }

    public void setFlushSleepTimeMilliseconds(int flushSleepTimeMilliseconds) {
        this.flushSleepTimeMilliseconds = flushSleepTimeMilliseconds;
    }

    public String getLogFileDir() {
        return logFileDir;
    }

    public void setLogFileDir(String logFileDir) {
        this.logFileDir = logFileDir;
    }

    public String getLogFileExt() {
        return logFileExt;
    }

    public void setLogFileExt(String logFileExt) {
        this.logFileExt = logFileExt;
    }

    public String getLogFileName() {
        return logFileName;
    }

    public void setLogFileName(String logFileName) {
        this.logFileName = logFileName;
    }

    public int getMaxBlocksPerFile() {
        return maxBlocksPerFile;
    }

    public void setMaxBlocksPerFile(int maxBlocksPerFile) {
        this.maxBlocksPerFile = maxBlocksPerFile;
    }

    public int getMaxBuffers() {
        return maxBuffers;
    }

    public void setMaxBuffers(int maxBuffers) {
        this.maxBuffers = maxBuffers;
    }

    public int getMaxLogFiles() {
        return maxLogFiles;
    }

    public void setMaxLogFiles(int maxLogFiles) {
        this.maxLogFiles = maxLogFiles;
    }

    public int getMinBuffers() {
        return minBuffers;
    }

    public void setMinBuffers(int minBuffers) {
        this.minBuffers = minBuffers;
    }

    public int getThreadsWaitingForceThreshold() {
        return threadsWaitingForceThreshold;
    }

    public void setThreadsWaitingForceThreshold(int threadsWaitingForceThreshold) {
        this.threadsWaitingForceThreshold = threadsWaitingForceThreshold;
    }

    public XidFactory getXidFactory() {
        return xidFactory;
    }

    public void setXidFactory(XidFactory xidFactory) {
        this.xidFactory = xidFactory;
    }

    public File getServerBaseDir() {
        return serverBaseDir;
    }

    public void setServerBaseDir(File serverBaseDir) {
        this.serverBaseDir = serverBaseDir;
    }
}
