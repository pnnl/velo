/**
 * Wrappers for {@link bibliothek.gui.DockStation}s, implementing {@link bibliothek.gui.dock.facile.mode.StationModeArea}.
 */
package bibliothek.gui.dock.facile.mode.station;