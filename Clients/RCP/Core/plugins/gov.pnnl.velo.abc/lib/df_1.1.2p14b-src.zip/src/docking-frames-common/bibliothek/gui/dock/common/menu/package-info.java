/**
 * Some {@link bibliothek.gui.dock.support.menu.MenuPiece}s to modify the layout and settings of an
 * application that uses <code>Common</code>.
 */
package bibliothek.gui.dock.common.menu;