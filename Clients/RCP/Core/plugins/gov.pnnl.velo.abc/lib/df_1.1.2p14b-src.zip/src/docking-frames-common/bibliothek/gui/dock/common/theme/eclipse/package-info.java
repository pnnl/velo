/**
 * Supporting classes for {@link bibliothek.gui.dock.common.theme.CEclipseTheme}.
 */
package bibliothek.gui.dock.common.theme.eclipse;