/**
 * Some utility classes required to precisely configure the behavior of
 * {@link bibliothek.gui.dock.common.action.CAction}s.
 */
package bibliothek.gui.dock.common.action.util;