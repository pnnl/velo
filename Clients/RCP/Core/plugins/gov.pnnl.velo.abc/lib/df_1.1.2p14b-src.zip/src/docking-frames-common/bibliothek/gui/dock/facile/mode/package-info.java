/**
 * Contains an implementation of {@link bibliothek.gui.dock.support.mode.ModeManager} that links a mode to the location
 * of a {@link bibliothek.gui.Dockable}. Contains various interfaces and classes to handle different modes.
 */
package bibliothek.gui.dock.facile.mode;