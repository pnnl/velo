/**
 * Supporting classes for {@link bibliothek.gui.dock.common.action.CPanelPopup}. These classes are factories and
 * helper classes needed to create the {@link java.awt.Component} which shows the action.
 */
package bibliothek.gui.dock.common.intern.action.panel;