/**
 * Offers a list containing factories for various {@link javax.swing.LookAndFeel}s. The list can exchange
 * the current {@link javax.swing.LookAndFeel} and update a set of {@link javax.swing.JComponent}.
 */
package bibliothek.gui.dock.support.lookandfeel;