/**
 * Implementations of {@link bibliothek.gui.dock.support.menu.MenuPiece}. These classes are intended to be 
 * used by clients directly without any need to subclass them.
 */
package bibliothek.gui.dock.facile.menu;