/**
 * Utility classes, used to load resources like icons or manage settings that need to be stored persistently.
 */
package bibliothek.gui.dock.support.util;