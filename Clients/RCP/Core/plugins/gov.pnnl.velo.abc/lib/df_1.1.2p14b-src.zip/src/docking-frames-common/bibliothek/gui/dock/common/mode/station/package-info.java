/**
 * Contains wrapper classes for various {@link bibliothek.gui.DockStation}s, implementing the interface
 * {@link bibliothek.gui.dock.common.mode.CLocationMode}.
 */
package bibliothek.gui.dock.common.mode.station;