/**
 * Some {@link bibliothek.gui.dock.action.DockAction}s used by <code>Common</code>.
 */
package bibliothek.gui.dock.facile.action;